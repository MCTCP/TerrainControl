package com.khorn.terraincontrol.forge.events;

import com.khorn.terraincontrol.LocalWorld;
import com.khorn.terraincontrol.TerrainControl;
import com.khorn.terraincontrol.forge.ForgeWorld;
import com.khorn.terraincontrol.forge.generator.Cartographer;
import com.khorn.terraincontrol.util.ChunkCoordinate;

import net.minecraftforge.event.world.ChunkEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChunkEventListener
{
	@SubscribeEvent
	public void onUnloadChunk(Unload event)
	{
		LocalWorld localWorld = TerrainControl.getEngine().getWorld(event.getWorld().getWorldInfo().getWorldName());
		if(localWorld != null)
		{
			Cartographer.CreateBlockWorldMapAtSpawn(ChunkCoordinate.fromChunkCoords(event.getChunk().xPosition, event.getChunk().zPosition), true);
		}
	}
}
