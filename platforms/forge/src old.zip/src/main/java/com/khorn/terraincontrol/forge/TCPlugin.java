package com.khorn.terraincontrol.forge;

import com.google.common.base.Function;
import com.khorn.terraincontrol.LocalBiome;
import com.khorn.terraincontrol.LocalWorld;
import com.khorn.terraincontrol.TerrainControl;
import com.khorn.terraincontrol.configuration.BiomeConfig;
import com.khorn.terraincontrol.configuration.standard.PluginStandardValues;
import com.khorn.terraincontrol.events.EventPriority;
import com.khorn.terraincontrol.exception.BiomeNotFoundException;
import com.khorn.terraincontrol.forge.client.events.ClientNetworkEventListener;
import com.khorn.terraincontrol.forge.events.*;
import com.khorn.terraincontrol.forge.generator.ForgeVanillaBiomeGenerator;
import com.khorn.terraincontrol.forge.generator.TCBlockPortal;
import com.khorn.terraincontrol.forge.generator.structure.RareBuildingStart;
import com.khorn.terraincontrol.forge.generator.structure.VillageStart;
import com.khorn.terraincontrol.forge.gui.GuiHandler;
import com.khorn.terraincontrol.generator.biome.VanillaBiomeGenerator;
import com.khorn.terraincontrol.logging.LogMarker;
import com.khorn.terraincontrol.util.minecraftTypes.StructureNames;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldProviderSurface;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.structure.MapGenStructureIO;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.ModContainer;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerAboutToStartEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;
import net.minecraftforge.fml.common.network.FMLEventChannel;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.io.File;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

@Mod(modid = "terraincontrol", name = "TerrainControl", acceptableRemoteVersions = "*")
public class TCPlugin
{
    private WorldLoader worldLoader;
    public static TCWorldType tcWorldType;

    @EventHandler
    public void load(FMLInitializationEvent event)
    {
        // This is the place where the mod starts loading
        File configsDir = new File(Loader.instance().getConfigDir(), "TerrainControl");
        this.worldLoader = new WorldLoader(configsDir);
        // Register World listener for tracking world unloads and loads.
        MinecraftForge.EVENT_BUS.register(new WorldListener(this.worldLoader));

        // Create the world type. WorldType registers itself in the constructor
        // - that is Mojang code, so don't blame me
        tcWorldType = new TCWorldType(this.worldLoader);

        // Start TerrainControl engine
        final ForgeEngine engine = new ForgeEngine(this.worldLoader);
        TerrainControl.setEngine(engine);

        // Register Default biome generator to TerrainControl
        engine.getBiomeModeManager().register(VanillaBiomeGenerator.GENERATOR_NAME, ForgeVanillaBiomeGenerator.class);

        // Register village and rare building starts
        MapGenStructureIO.registerStructure(RareBuildingStart.class, StructureNames.RARE_BUILDING);
        MapGenStructureIO.registerStructure(VillageStart.class, StructureNames.VILLAGE);

        // Register listening channel for listening to received configs.
        if (event.getSide() == Side.CLIENT)
        {
            ClientNetworkEventListener networkHandler = new ClientNetworkEventListener(this.worldLoader);
            FMLEventChannel eventDrivenChannel = NetworkRegistry.INSTANCE.newEventDrivenChannel(
                    PluginStandardValues.ChannelName);
            eventDrivenChannel.register(networkHandler);
            MinecraftForge.EVENT_BUS.register(networkHandler);
        }

        // Register player tracker, for sending configs.
        MinecraftForge.EVENT_BUS.register(new PlayerTracker(this.worldLoader));

        // Register sapling tracker, for custom tree growth.
        SaplingListener saplingListener = new SaplingListener(this.worldLoader);
        MinecraftForge.TERRAIN_GEN_BUS.register(saplingListener);
        MinecraftForge.EVENT_BUS.register(saplingListener);

        // Register colorizer, for biome colors
        Function<Biome, BiomeConfig> getBiomeConfig = new Function<Biome, BiomeConfig>()
        {
            @Override
            public BiomeConfig apply(Biome input)
            {
                LocalBiome biome = null;
                for (LocalWorld world : TCPlugin.this.worldLoader.worlds.values())
                {
                    try
                    {
                        //biome = world.getBiomeByName(input.getBiomeName());
                    	biome = TerrainControl.getBiomeAllWorlds(input.getBiomeName());
                        break;
                    } catch (BiomeNotFoundException e)
                    {
                        // Ignored, try in next world
                    }
                }

                if (biome == null)
                {
                    return null;
                }

                return biome.getBiomeConfig();
            }
        };
        MinecraftForge.EVENT_BUS.register(new BiomeColorsListener(getBiomeConfig));

        // Register server tick handler for pre-generation of worlds
        MinecraftForge.EVENT_BUS.register(new ServerEventListener());

        MinecraftForge.EVENT_BUS.register(new GuiHandler());

        // Register KeyBoardEventListener for toggling pre-generator in-game UI using F3
        MinecraftForge.EVENT_BUS.register(new KeyBoardEventListener());

        // Register to our own events, so that they can be fired again as Forge events.
        engine.registerEventHandler(new TCToForgeEventConverter(), EventPriority.CANCELABLE);

        // Register RightClickBlockListener for detecting fire and creating portals
        MinecraftForge.EVENT_BUS.register(new RightClickBlockListener());
        
        // Register EntityTravelToDimensionListener for quartz portals that tp to other dimensions
        MinecraftForge.EVENT_BUS.register(new EntityTravelToDimensionListener());
        
		if(TerrainControl.getPluginConfig().Cartographer)
		{
	        // Register ChunkLoadListener for updating Cartographer map
	        MinecraftForge.EVENT_BUS.register(new ChunkEventListener());	        
		}
    }
    
    @SideOnly(Side.CLIENT)
    @EventHandler
    public void onIntegratedServerAboutToStart(FMLServerAboutToStartEvent event)
    {
        this.worldLoader.onServerAboutToLoad(event.getServer().getWorldName());
    }

    @SideOnly(Side.SERVER)
    @EventHandler
    public void onDedicatedServerPostInit(FMLPostInitializationEvent event)
    {
        this.worldLoader.onServerAboutToLoad(null);
    } 

    @SideOnly(Side.SERVER)
    @EventHandler
    public void onDedicatedServerStopped(FMLServerStoppingEvent event)
    {
        this.worldLoader.onServerStopped();
    }

    @EventHandler
    public void serverLoad(FMLServerStartingEvent event)
    {
        event.registerServerCommand(new TCCommandHandler());
    }

}