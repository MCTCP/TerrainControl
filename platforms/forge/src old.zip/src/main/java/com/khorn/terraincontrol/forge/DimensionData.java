package com.khorn.terraincontrol.forge;

public class DimensionData
{
	public int dimensionId;
	public String dimensionName;
	public boolean keepLoaded;
	public long seed = 0;
}
