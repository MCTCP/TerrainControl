package com.khorn.terraincontrol.forge.events;

import com.khorn.terraincontrol.TerrainControl;
import com.khorn.terraincontrol.forge.ForgeEngine;
import com.khorn.terraincontrol.forge.ForgeWorld;
import com.khorn.terraincontrol.forge.TCDimensionManager;
import com.khorn.terraincontrol.forge.TCWorldType;
import com.khorn.terraincontrol.forge.WorldLoader;
import com.khorn.terraincontrol.forge.WorldProviderTC;
import com.khorn.terraincontrol.forge.generator.Cartographer;
import com.khorn.terraincontrol.forge.util.WorldHelper;
import com.khorn.terraincontrol.logging.LogMarker;

import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;

public class WorldListener
{

    private WorldLoader worldLoader;

    public WorldListener(WorldLoader worldLoader)
    {
        this.worldLoader = worldLoader;
    }

	@SubscribeEvent
	public void onWorldSave(WorldEvent.Save event)
	{
		((ForgeEngine)TerrainControl.getEngine()).getPregenerator().SavePreGeneratorData(event.getWorld());
	}
    
	@SubscribeEvent
	public void onWorldTick(TickEvent.WorldTickEvent event)
	{
		if(event.phase == Phase.START)
		{
			int dimId = event.world.provider.getDimension();
			TerrainControl.log(LogMarker.INFO, "Ticking world " + event.world.getWorldInfo().getWorldName() + " at dim " + dimId);
		}
	}

	@SubscribeEvent
	public void onWorldLoadEvent(WorldEvent.Load event)
	{	
		if(event.getWorld().provider.getDimension() == 0)
		{
			Cartographer.CreateCartographerDimension();		
		}
	}
	
    // TODO: This method should not be called by DimensionManager when switching dimensions (main -> nether -> main). Find out why it is being called
    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event)
    {
        World mcWorld = event.getWorld();
    	
    	int dimId = event.getWorld().provider.getDimension();
    	if(event.getWorld().getWorldType() instanceof TCWorldType && dimId > 1)
    	{
    		if(!event.getWorld().getWorldInfo().getWorldName().equals("MpServer")) // MpServer == client side?
    		{
    			if((ForgeWorld)((TCWorldType)event.getWorld().getWorldType()).worldLoader.getWorld(event.getWorld()) != null)
    			{    				
	    			TerrainControl.log(LogMarker.INFO, "Unloading world " + event.getWorld().getWorldInfo().getWorldName() + " at dim " + dimId);
	    			// DimensionManager.setWorld(dimId, null, server);
	    			((TCWorldType)event.getWorld().getWorldType()).worldLoader.unloadWorld(event.getWorld());
    			} else {
    				// World has already been unloaded, only happens when shutting down server?
    			}
    		}
    	}

        if(mcWorld.provider instanceof WorldProviderTC)
        {
	        ForgeWorld forgeWorld = this.worldLoader.getWorld(WorldHelper.getName(mcWorld));

	        MinecraftServer mcServer = mcWorld.getMinecraftServer();
	        if(mcServer == null)
	        {
	        	mcServer = Minecraft.getMinecraft().getIntegratedServer();
	        }
	        
	        if (forgeWorld == null && mcWorld.getMinecraftServer() != null && !mcServer.isServerRunning()) // If the server is stopping
	        {
	        	TCDimensionManager.UnloadCustomDimensionData(mcWorld.provider.getDimension());        	
	        }
        }
    	
    	/*
        if(event.getWorld().provider.getDimension() != 0) // Temporary fix, this may break multi-world support (I assume it uses dimensions to load other worlds?) 
        {
            World mcWorld = event.getWorld();           
            ForgeWorld forgeWorld = this.worldLoader.getWorld(WorldHelper.getName(mcWorld));
            if (forgeWorld == null)
            {
                return;
            }
            
        	((ForgeEngine)TerrainControl.getEngine()).getPregenerator().shutDown(mcWorld);
        	this.worldLoader.unloadWorld(forgeWorld);
        }
        */
    }
}
