/**
 * These classes allow you to launch TerrainControl from your IDE.
 */
package com.khorn.terraincontrol.forge.launch;